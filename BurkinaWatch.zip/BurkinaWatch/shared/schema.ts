import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, decimal, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  telephone: varchar("telephone"),
  bio: text("bio"),
  ville: varchar("ville"),
  role: varchar("role").default("citoyen"),
  emailTrackingEnabled: boolean("email_tracking_enabled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const signalements = pgTable("signalements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titre: text("titre").notNull(),
  description: text("description").notNull(),
  categorie: text("categorie").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  localisation: text("localisation"),
  photo: text("photo"),
  video: text("video"),
  userId: varchar("user_id"),
  isAnonymous: boolean("is_anonymous").default(false),
  isSOS: boolean("is_sos").default(false),
  niveauUrgence: text("niveau_urgence"),
  statut: text("statut").default("en_attente"),
  likes: integer("likes").default(0),
  commentairesCount: integer("commentaires_count").default(0),
  sharesCount: integer("shares_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const commentaires = pgTable("commentaires", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  signalementId: varchar("signalement_id").references(() => signalements.id).notNull(),
  userId: varchar("user_id").references(() => users.id),
  contenu: text("contenu").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trackingSessions = pgTable("tracking_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const locationPoints = pgTable("location_points", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => trackingSessions.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  accuracy: decimal("accuracy", { precision: 10, scale: 2 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const upsertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
  role: true,
});

export const updateUserProfileSchema = createInsertSchema(users).omit({
  id: true,
  email: true,
  createdAt: true,
  updatedAt: true,
  role: true,
}).partial();

export const insertSignalementSchema = createInsertSchema(signalements, {
  latitude: z.union([z.string(), z.number()]).transform(val => String(val)),
  longitude: z.union([z.string(), z.number()]).transform(val => String(val)),
  photo: z.string().optional(),
  video: z.string().optional(),
  localisation: z.string().optional(),
  niveauUrgence: z.string().optional(),
}).omit({
  id: true,
  createdAt: true,
  likes: true,
  commentairesCount: true,
  sharesCount: true,
  statut: true,
});

export const updateSignalementSchema = createInsertSchema(signalements, {
  latitude: z.union([z.string(), z.number()]).transform(val => String(val)),
  longitude: z.union([z.string(), z.number()]).transform(val => String(val)),
  photo: z.string().optional(),
  video: z.string().optional(),
  localisation: z.string().optional(),
  niveauUrgence: z.string().optional(),
  statut: z.enum(["en_attente", "en_cours", "resolu", "rejete"]).optional(),
}).omit({
  id: true,
  createdAt: true,
  likes: true,
  commentairesCount: true,
  sharesCount: true,
  userId: true,
  isAnonymous: true,
  isSOS: true,
}).partial();

export const insertCommentaireSchema = createInsertSchema(commentaires).omit({
  id: true,
  createdAt: true,
});

export const insertTrackingSessionSchema = createInsertSchema(trackingSessions).omit({
  id: true,
  startTime: true,
  isActive: true,
});

export const insertLocationPointSchema = createInsertSchema(locationPoints, {
  latitude: z.union([z.string(), z.number()]).transform(val => String(val)),
  longitude: z.union([z.string(), z.number()]).transform(val => String(val)),
  accuracy: z.union([z.string(), z.number()]).transform(val => String(val)).optional(),
}).omit({
  id: true,
  timestamp: true,
});

export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;
export type User = typeof users.$inferSelect;
export type InsertSignalement = z.infer<typeof insertSignalementSchema>;
export type UpdateSignalement = z.infer<typeof updateSignalementSchema>;
export type Signalement = typeof signalements.$inferSelect;
export type InsertCommentaire = z.infer<typeof insertCommentaireSchema>;
export type Commentaire = typeof commentaires.$inferSelect;
export type InsertTrackingSession = z.infer<typeof insertTrackingSessionSchema>;
export type TrackingSession = typeof trackingSessions.$inferSelect;
export type InsertLocationPoint = z.infer<typeof insertLocationPointSchema>;
export type LocationPoint = typeof locationPoints.$inferSelect;

export type SignalementWithAuthor = Signalement & {
  auteurFirstName?: string | null;
  auteurLastName?: string | null;
};

export type TrackingSessionWithTrajectory = TrackingSession & {
  trajectoryUrl: string | null;
  pointCount: number;
};

export const categories = ["urgence", "securite", "sante", "environnement", "corruption", "infrastructure", "personne_recherchee"] as const;
export const statuts = ["en_attente", "en_cours", "resolu", "rejete"] as const;
export const niveauxUrgence = ["faible", "moyen", "critique"] as const;

export type Categorie = typeof categories[number];
export type Statut = typeof statuts[number];
export type NiveauUrgence = typeof niveauxUrgence[number];

import { 
  type User, 
  type UpsertUser,
  type UpdateUserProfile,
  type Signalement,
  type SignalementWithAuthor,
  type InsertSignalement,
  type UpdateSignalement,
  type Commentaire,
  type InsertCommentaire,
  type TrackingSession,
  type InsertTrackingSession,
  type LocationPoint,
  type InsertLocationPoint,
  users,
  signalements,
  commentaires,
  trackingSessions,
  locationPoints,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfile(id: string, profile: UpdateUserProfile): Promise<User | undefined>;
  
  getSignalements(filters?: {
    categorie?: string;
    statut?: string;
    isSOS?: boolean;
    limit?: number;
  }): Promise<SignalementWithAuthor[]>;
  getUserSignalements(userId: string): Promise<SignalementWithAuthor[]>;
  getSignalement(id: string): Promise<Signalement | undefined>;
  createSignalement(signalement: InsertSignalement): Promise<Signalement>;
  updateSignalement(id: string, updates: UpdateSignalement): Promise<Signalement | undefined>;
  deleteSignalement(id: string): Promise<boolean>;
  updateSignalementStatut(id: string, statut: string): Promise<Signalement | undefined>;
  likeSignalement(id: string): Promise<Signalement | undefined>;
  shareSignalement(id: string): Promise<Signalement | undefined>;
  
  getCommentaires(signalementId: string): Promise<Commentaire[]>;
  createCommentaire(commentaire: InsertCommentaire): Promise<Commentaire>;
  
  getStats(): Promise<{
    totalSignalements: number;
    sosCount: number;
    totalUsers: number;
  }>;
  
  startTrackingSession(userId: string): Promise<TrackingSession>;
  stopTrackingSession(sessionId: string): Promise<TrackingSession | undefined>;
  getActiveTrackingSession(userId: string): Promise<TrackingSession | undefined>;
  addLocationPoint(locationPoint: InsertLocationPoint): Promise<LocationPoint>;
  getSessionLocationPoints(sessionId: string): Promise<LocationPoint[]>;
  getUserTrackingSessions(userId: string): Promise<TrackingSession[]>;
}

export class DbStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!email) return undefined;
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfile(id: string, profile: UpdateUserProfile): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({
        ...profile,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getSignalements(filters?: {
    categorie?: string;
    statut?: string;
    isSOS?: boolean;
    limit?: number;
  }): Promise<SignalementWithAuthor[]> {
    let query = db
      .select({
        id: signalements.id,
        titre: signalements.titre,
        description: signalements.description,
        categorie: signalements.categorie,
        latitude: signalements.latitude,
        longitude: signalements.longitude,
        localisation: signalements.localisation,
        photo: signalements.photo,
        video: signalements.video,
        userId: signalements.userId,
        isAnonymous: signalements.isAnonymous,
        isSOS: signalements.isSOS,
        niveauUrgence: signalements.niveauUrgence,
        statut: signalements.statut,
        likes: signalements.likes,
        commentairesCount: signalements.commentairesCount,
        sharesCount: signalements.sharesCount,
        createdAt: signalements.createdAt,
        auteurFirstName: users.firstName,
        auteurLastName: users.lastName,
      })
      .from(signalements)
      .leftJoin(users, eq(signalements.userId, users.id));
    
    const conditions = [];
    if (filters?.categorie) {
      conditions.push(eq(signalements.categorie, filters.categorie));
    }
    if (filters?.statut) {
      conditions.push(eq(signalements.statut, filters.statut));
    }
    if (filters?.isSOS !== undefined) {
      conditions.push(eq(signalements.isSOS, filters.isSOS));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    query = query.orderBy(desc(signalements.createdAt)) as any;

    if (filters?.limit) {
      query = query.limit(filters.limit) as any;
    }

    return await query;
  }

  async getUserSignalements(userId: string): Promise<SignalementWithAuthor[]> {
    return await db
      .select({
        id: signalements.id,
        titre: signalements.titre,
        description: signalements.description,
        categorie: signalements.categorie,
        latitude: signalements.latitude,
        longitude: signalements.longitude,
        localisation: signalements.localisation,
        photo: signalements.photo,
        video: signalements.video,
        userId: signalements.userId,
        isAnonymous: signalements.isAnonymous,
        isSOS: signalements.isSOS,
        niveauUrgence: signalements.niveauUrgence,
        statut: signalements.statut,
        likes: signalements.likes,
        commentairesCount: signalements.commentairesCount,
        sharesCount: signalements.sharesCount,
        createdAt: signalements.createdAt,
        auteurFirstName: users.firstName,
        auteurLastName: users.lastName,
      })
      .from(signalements)
      .leftJoin(users, eq(signalements.userId, users.id))
      .where(eq(signalements.userId, userId))
      .orderBy(desc(signalements.createdAt));
  }

  async getSignalement(id: string): Promise<Signalement | undefined> {
    const result = await db.select().from(signalements).where(eq(signalements.id, id)).limit(1);
    return result[0];
  }

  async createSignalement(insertSignalement: InsertSignalement): Promise<Signalement> {
    const result = await db.insert(signalements).values(insertSignalement).returning();
    return result[0];
  }

  async updateSignalement(id: string, updates: UpdateSignalement): Promise<Signalement | undefined> {
    const result = await db
      .update(signalements)
      .set(updates)
      .where(eq(signalements.id, id))
      .returning();
    return result[0];
  }

  async deleteSignalement(id: string): Promise<boolean> {
    const result = await db
      .delete(signalements)
      .where(eq(signalements.id, id))
      .returning();
    return result.length > 0;
  }

  async updateSignalementStatut(id: string, statut: string): Promise<Signalement | undefined> {
    const result = await db
      .update(signalements)
      .set({ statut })
      .where(eq(signalements.id, id))
      .returning();
    return result[0];
  }

  async likeSignalement(id: string): Promise<Signalement | undefined> {
    const result = await db
      .update(signalements)
      .set({ likes: sql`${signalements.likes} + 1` })
      .where(eq(signalements.id, id))
      .returning();
    return result[0];
  }

  async shareSignalement(id: string): Promise<Signalement | undefined> {
    const result = await db
      .update(signalements)
      .set({ sharesCount: sql`${signalements.sharesCount} + 1` })
      .where(eq(signalements.id, id))
      .returning();
    return result[0];
  }

  async getCommentaires(signalementId: string): Promise<Commentaire[]> {
    return await db
      .select()
      .from(commentaires)
      .where(eq(commentaires.signalementId, signalementId))
      .orderBy(desc(commentaires.createdAt));
  }

  async createCommentaire(insertCommentaire: InsertCommentaire): Promise<Commentaire> {
    const result = await db.insert(commentaires).values(insertCommentaire).returning();
    
    await db
      .update(signalements)
      .set({ commentairesCount: sql`${signalements.commentairesCount} + 1` })
      .where(eq(signalements.id, insertCommentaire.signalementId));
    
    return result[0];
  }

  async getStats(): Promise<{
    totalSignalements: number;
    sosCount: number;
    totalUsers: number;
  }> {
    const [totalSignalementsResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(signalements);
    
    const [sosCountResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(signalements)
      .where(eq(signalements.isSOS, true));
    
    const [totalUsersResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users);
    
    return {
      totalSignalements: totalSignalementsResult?.count || 0,
      sosCount: sosCountResult?.count || 0,
      totalUsers: totalUsersResult?.count || 0,
    };
  }

  async startTrackingSession(userId: string): Promise<TrackingSession> {
    const activeSession = await this.getActiveTrackingSession(userId);
    if (activeSession) {
      await this.stopTrackingSession(activeSession.id);
    }
    
    const [session] = await db
      .insert(trackingSessions)
      .values({ userId })
      .returning();
    return session;
  }

  async stopTrackingSession(sessionId: string): Promise<TrackingSession | undefined> {
    const [session] = await db
      .update(trackingSessions)
      .set({ 
        isActive: false,
        endTime: new Date(),
      })
      .where(eq(trackingSessions.id, sessionId))
      .returning();
    return session;
  }

  async getActiveTrackingSession(userId: string): Promise<TrackingSession | undefined> {
    const [session] = await db
      .select()
      .from(trackingSessions)
      .where(
        and(
          eq(trackingSessions.userId, userId),
          eq(trackingSessions.isActive, true)
        )
      )
      .limit(1);
    return session;
  }

  async addLocationPoint(locationPoint: InsertLocationPoint): Promise<LocationPoint> {
    const [point] = await db
      .insert(locationPoints)
      .values(locationPoint)
      .returning();
    return point;
  }

  async getSessionLocationPoints(sessionId: string): Promise<LocationPoint[]> {
    return await db
      .select()
      .from(locationPoints)
      .where(eq(locationPoints.sessionId, sessionId))
      .orderBy(locationPoints.timestamp);
  }

  async getUserTrackingSessions(userId: string): Promise<TrackingSession[]> {
    return await db
      .select()
      .from(trackingSessions)
      .where(eq(trackingSessions.userId, userId))
      .orderBy(desc(trackingSessions.startTime))
      .limit(10);
  }
}

export const storage = new DbStorage();

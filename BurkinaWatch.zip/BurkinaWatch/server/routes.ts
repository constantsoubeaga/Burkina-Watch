import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSignalementSchema, updateSignalementSchema, insertCommentaireSchema, updateUserProfileSchema, insertLocationPointSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { setupAuth, isAuthenticated } from "./replitAuth";

export async function registerRoutes(app: Express): Promise<Server> {
  await setupAuth(app);

  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.patch("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validationResult = updateUserProfileSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const errorMessage = fromZodError(validationResult.error).toString();
        return res.status(400).json({ error: errorMessage });
      }
      
      const user = await storage.updateUserProfile(userId, validationResult.data);
      
      if (!user) {
        return res.status(404).json({ error: "Utilisateur non trouvé" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ error: "Erreur lors de la mise à jour du profil" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Erreur lors de la récupération des statistiques" });
    }
  });

  app.get("/api/signalements", async (req, res) => {
    try {
      const { categorie, statut, isSOS, limit } = req.query;
      
      const signalements = await storage.getSignalements({
        categorie: categorie as string | undefined,
        statut: statut as string | undefined,
        isSOS: isSOS === "true" ? true : isSOS === "false" ? false : undefined,
        limit: limit ? parseInt(limit as string) : undefined,
      });
      
      res.json(signalements);
    } catch (error) {
      console.error("Error fetching signalements:", error);
      res.status(500).json({ error: "Erreur lors de la récupération des signalements" });
    }
  });

  app.get("/api/signalements/:id", async (req, res) => {
    try {
      const signalement = await storage.getSignalement(req.params.id);
      
      if (!signalement) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      res.json(signalement);
    } catch (error) {
      console.error("Error fetching signalement:", error);
      res.status(500).json({ error: "Erreur lors de la récupération du signalement" });
    }
  });

  app.post("/api/signalements", async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || "demo-user";
      const validationResult = insertSignalementSchema.safeParse({
        ...req.body,
        userId,
      });
      
      if (!validationResult.success) {
        const errorMessage = fromZodError(validationResult.error).toString();
        return res.status(400).json({ error: errorMessage });
      }
      
      const signalement = await storage.createSignalement(validationResult.data);
      
      // Ne pas renvoyer les images base64 dans la réponse pour éviter les problèmes de taille
      const { photo, video, ...signalementWithoutMedia } = signalement;
      res.status(201).json({
        ...signalementWithoutMedia,
        photo: photo ? "[IMAGE_DATA]" : null,
        video: video ? "[VIDEO_DATA]" : null,
      });
    } catch (error) {
      console.error("Error creating signalement:", error);
      res.status(500).json({ error: "Erreur lors de la création du signalement" });
    }
  });

  app.get("/api/auth/user/signalements", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const signalements = await storage.getUserSignalements(userId);
      res.json(signalements);
    } catch (error) {
      console.error("Error fetching user signalements:", error);
      res.status(500).json({ error: "Erreur lors de la récupération des signalements" });
    }
  });

  app.patch("/api/signalements/:id", async (req: any, res) => {
    try {
      const signalement = await storage.getSignalement(req.params.id);
      
      if (!signalement) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      // Demo mode: Allow editing signalements created by demo-user
      // Authenticated mode: Only the owner can edit their own signalements
      const userId = req.user?.claims?.sub || "demo-user";
      
      // Security check: Only allow editing if:
      // 1. Signalement belongs to demo-user (demo mode), OR
      // 2. User is authenticated AND owns this signalement
      const isDemoSignalement = signalement.userId === "demo-user";
      const isOwner = signalement.userId === userId;
      
      if (!isDemoSignalement && !isOwner) {
        return res.status(403).json({ error: "Vous n'êtes pas autorisé à modifier ce signalement" });
      }
      
      // If signalement is not a demo signalement, require authentication
      if (!isDemoSignalement && !req.user) {
        return res.status(401).json({ error: "Authentification requise" });
      }
      
      const validationResult = updateSignalementSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const errorMessage = fromZodError(validationResult.error).toString();
        return res.status(400).json({ error: errorMessage });
      }
      
      const updatedSignalement = await storage.updateSignalement(req.params.id, validationResult.data);
      res.json(updatedSignalement);
    } catch (error) {
      console.error("Error updating signalement:", error);
      res.status(500).json({ error: "Erreur lors de la mise à jour du signalement" });
    }
  });

  app.delete("/api/signalements/:id", async (req: any, res) => {
    try {
      const signalement = await storage.getSignalement(req.params.id);
      
      if (!signalement) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      // Demo mode: Allow deleting signalements created by demo-user
      // Authenticated mode: Only the owner can delete their own signalements
      const userId = req.user?.claims?.sub || "demo-user";
      
      // Security check: Only allow deleting if:
      // 1. Signalement belongs to demo-user (demo mode), OR
      // 2. User is authenticated AND owns this signalement
      const isDemoSignalement = signalement.userId === "demo-user";
      const isOwner = signalement.userId === userId;
      
      if (!isDemoSignalement && !isOwner) {
        return res.status(403).json({ error: "Vous n'êtes pas autorisé à supprimer ce signalement" });
      }
      
      // If signalement is not a demo signalement, require authentication
      if (!isDemoSignalement && !req.user) {
        return res.status(401).json({ error: "Authentification requise" });
      }
      
      const success = await storage.deleteSignalement(req.params.id);
      
      if (!success) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      res.json({ message: "Signalement supprimé avec succès" });
    } catch (error) {
      console.error("Error deleting signalement:", error);
      res.status(500).json({ error: "Erreur lors de la suppression du signalement" });
    }
  });

  app.patch("/api/signalements/:id/statut", async (req, res) => {
    try {
      const { statut } = req.body;
      
      if (!statut || !["en_attente", "en_cours", "resolu", "rejete"].includes(statut)) {
        return res.status(400).json({ error: "Statut invalide" });
      }
      
      const signalement = await storage.updateSignalementStatut(req.params.id, statut);
      
      if (!signalement) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      res.json(signalement);
    } catch (error) {
      console.error("Error updating signalement statut:", error);
      res.status(500).json({ error: "Erreur lors de la mise à jour du statut" });
    }
  });

  app.post("/api/signalements/:id/like", async (req, res) => {
    try {
      const signalement = await storage.likeSignalement(req.params.id);
      
      if (!signalement) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      res.json(signalement);
    } catch (error) {
      console.error("Error liking signalement:", error);
      res.status(500).json({ error: "Erreur lors du like" });
    }
  });

  app.post("/api/signalements/:id/share", async (req, res) => {
    try {
      const signalement = await storage.shareSignalement(req.params.id);
      
      if (!signalement) {
        return res.status(404).json({ error: "Signalement non trouvé" });
      }
      
      res.json(signalement);
    } catch (error) {
      console.error("Error sharing signalement:", error);
      res.status(500).json({ error: "Erreur lors du partage" });
    }
  });

  app.get("/api/signalements/:id/commentaires", async (req, res) => {
    try {
      const commentaires = await storage.getCommentaires(req.params.id);
      res.json(commentaires);
    } catch (error) {
      console.error("Error fetching commentaires:", error);
      res.status(500).json({ error: "Erreur lors de la récupération des commentaires" });
    }
  });

  app.post("/api/commentaires", async (req, res) => {
    try {
      const validationResult = insertCommentaireSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const errorMessage = fromZodError(validationResult.error).toString();
        return res.status(400).json({ error: errorMessage });
      }
      
      const commentaire = await storage.createCommentaire(validationResult.data);
      res.status(201).json(commentaire);
    } catch (error) {
      console.error("Error creating commentaire:", error);
      res.status(500).json({ error: "Erreur lors de la création du commentaire" });
    }
  });

  app.post("/api/tracking/start", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const session = await storage.startTrackingSession(userId);
      res.status(201).json(session);
    } catch (error) {
      console.error("Error starting tracking session:", error);
      res.status(500).json({ error: "Erreur lors du démarrage du tracking" });
    }
  });

  app.post("/api/tracking/stop", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activeSession = await storage.getActiveTrackingSession(userId);
      
      if (!activeSession) {
        return res.status(404).json({ error: "Aucune session de tracking active" });
      }
      
      const session = await storage.stopTrackingSession(activeSession.id);
      res.json(session);
    } catch (error) {
      console.error("Error stopping tracking session:", error);
      res.status(500).json({ error: "Erreur lors de l'arrêt du tracking" });
    }
  });

  app.get("/api/tracking/session", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const session = await storage.getActiveTrackingSession(userId);
      
      if (!session) {
        return res.status(404).json({ error: "Aucune session de tracking active" });
      }
      
      res.json(session);
    } catch (error) {
      console.error("Error fetching active tracking session:", error);
      res.status(500).json({ error: "Erreur lors de la récupération de la session" });
    }
  });

  app.post("/api/tracking/location", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activeSession = await storage.getActiveTrackingSession(userId);
      
      if (!activeSession) {
        return res.status(404).json({ error: "Aucune session de tracking active" });
      }
      
      const validationResult = insertLocationPointSchema.safeParse({
        ...req.body,
        sessionId: activeSession.id,
        userId,
      });
      
      if (!validationResult.success) {
        const errorMessage = fromZodError(validationResult.error).toString();
        return res.status(400).json({ error: errorMessage });
      }
      
      const locationPoint = await storage.addLocationPoint(validationResult.data);
      res.status(201).json(locationPoint);
    } catch (error) {
      console.error("Error adding location point:", error);
      res.status(500).json({ error: "Erreur lors de l'ajout du point de localisation" });
    }
  });

  app.get("/api/tracking/sessions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessions = await storage.getUserTrackingSessions(userId);
      
      const sessionsWithTrajectory = await Promise.all(
        sessions.map(async (session) => {
          const points = await storage.getSessionLocationPoints(session.id);
          
          let trajectoryUrl = null;
          if (points.length > 0) {
            const sortedPoints = points.sort((a, b) => 
              new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
            );
            
            if (sortedPoints.length === 1) {
              const point = sortedPoints[0];
              trajectoryUrl = `https://www.google.com/maps?q=${point.latitude},${point.longitude}`;
            } else {
              const firstPoint = sortedPoints[0];
              const lastPoint = sortedPoints[sortedPoints.length - 1];
              
              const waypoints = sortedPoints.slice(1, -1)
                .filter((_, index) => index % Math.max(1, Math.floor((sortedPoints.length - 2) / 8)) === 0)
                .map(p => `${p.latitude},${p.longitude}`)
                .join('|');
              
              const origin = `${firstPoint.latitude},${firstPoint.longitude}`;
              const destination = `${lastPoint.latitude},${lastPoint.longitude}`;
              
              if (waypoints) {
                trajectoryUrl = `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&waypoints=${waypoints}&travelmode=walking`;
              } else {
                trajectoryUrl = `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&travelmode=walking`;
              }
            }
          }
          
          return {
            ...session,
            trajectoryUrl,
            pointCount: points.length
          };
        })
      );
      
      res.json(sessionsWithTrajectory);
    } catch (error) {
      console.error("Error fetching tracking sessions:", error);
      res.status(500).json({ error: "Erreur lors de la récupération des sessions" });
    }
  });

  app.get("/api/tracking/sessions/:id/points", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionId = req.params.id;
      
      const session = await storage.getActiveTrackingSession(userId);
      if (!session || session.id !== sessionId) {
        const sessions = await storage.getUserTrackingSessions(userId);
        const sessionExists = sessions.find(s => s.id === sessionId);
        
        if (!sessionExists) {
          return res.status(403).json({ error: "Session non trouvée ou non autorisée" });
        }
      }
      
      const points = await storage.getSessionLocationPoints(sessionId);
      res.json(points);
    } catch (error) {
      console.error("Error fetching session location points:", error);
      res.status(500).json({ error: "Erreur lors de la récupération des points" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

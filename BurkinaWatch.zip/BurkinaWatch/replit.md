# Burkina Watch - Application Nationale de Veille Citoyenne

## Overview

Burkina Watch is a full-stack web application designed for civic engagement in Burkina Faso. It enables citizens to anonymously report incidents (accidents, corruption, infrastructure issues), request or offer help via an SOS feature, and visualize real-time reports on an interactive map. Public institutions can respond to these reports through a secure professional interface. The platform prioritizes reliability, simplicity, accessibility, and mobile responsiveness, even on low-bandwidth connections. Key capabilities include Google authentication, comprehensive profile protection, an urgency indicator system for reports, user-editable signalements, and clickable location points integrated with Google Maps.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend

*   **Framework**: React 18 with TypeScript and Vite.
*   **UI/UX**: Shadcn/ui components (Radix UI, Tailwind CSS - New York variant). Ecological and security-focused design with a primary green color palette (HSL 142° 65% 45% light, 142° 60% 55% dark) for nature, security, and environmental awareness. WCAG AA compliant contrast. The slogan "Voir. Agir. Protéger." uses national colors (Red, Yellow, Green) reflecting the Burkinabé flag. Urgency is indicated by a traffic light color system.
*   **Routing**: Wouter for client-side routing with protected routes.
*   **State Management**: TanStack Query for server state, React Context for theme, React hooks for local state.
*   **Key Pages**: Landing, Home, Feed (filterable), Interactive Map (signalements, SOS), Report Creation (`/publier`), SOS Publishing (`/sos/publier`), Notifications, User Profile, Admin, Contribution (`/contribuer`), About (`/a-propos`), Terms of Use (`/conditions`).
*   **Features**: Dynamic "Message du Jour" on homepage, interactive map with marker clustering and local statistics (SOS markers unclustered), clickable location points opening Google Maps, automatic image compression on upload (1200x1200px, 80% JPEG quality, max 20MB before compression), dynamic SOS filtering system (Urgences, Demandes d'aide, Personnes recherchées), professional hamburger navigation menu, detailed "About" and "Terms of Use" pages, and a "Contribution" page for mobile money donations. Social features include a like system, comment system, and share functionality. **Live Location Tracking**: Users can start/stop real-time location tracking from their profile page; the system records GPS coordinates every 30 seconds to create a safety trajectory that can be used by emergency services to locate citizens in case of incidents or accidents. The tracking automatically resumes after page reload if a session is active, with synchronized point counter displaying the number of recorded positions. **Trajectory Visualization**: Each tracking session automatically generates a Google Maps link displaying the complete trajectory for investigation and search purposes. Users can copy the link or open it directly; the system intelligently samples waypoints (max 8) to respect Google Maps API limits while preserving route accuracy.

### Backend

*   **Runtime**: Node.js with Express.js.
*   **Language**: TypeScript with ES modules.
*   **API Design**: RESTful endpoints (`/api`) for authentication, reports, comments, and user profiles.
*   **Session Management**: Express sessions with PostgreSQL session store.

### Database

*   **ORM**: Drizzle ORM with PostgreSQL dialect via Neon serverless driver.
*   **Schema**: `users`, `signalements` (geolocation, category, status, media URLs, anonymous/SOS flags, urgency, likes), `commentaires`, `sessions`, `trackingSessions` (live location tracking sessions), `locationPoints` (GPS coordinates with timestamps).
*   **Migrations**: Schema-first approach with Drizzle Kit.

### Authentication & Authorization

*   **Provider**: OpenID Connect (OIDC) via Replit Auth (Google, GitHub, X, Apple, email/password).
*   **Strategy**: Passport.js with `openid-client`.
*   **Session Storage**: PostgreSQL-backed sessions with 7-day TTL.
*   **User Flow**: Authentication required for reports, comments, profile; anonymous access for public content.
*   **Authorization**: Role-based access control; "citoyen" default, support for institutional roles.

### Data Validation

*   **Schema Validation**: Zod schemas generated from Drizzle schemas (`drizzle-zod`).
*   **Error Handling**: `Zod-validation-error` for user-friendly messages.
*   **Form Validation**: React Hook Form with Zod resolver (client-side) and server-side request body validation.

### Styling System

*   **Framework**: Tailwind CSS with custom configuration.
*   **Theme**: Ecological and security-focused palette with dominant greens, using CSS custom properties for light/dark modes. WCAG AA compliance.
*   **Typography**: Inter font family from Google Fonts.

### Build and Deployment

*   **Development**: `npm run dev` (Express with Vite middleware, HMR).
*   **Production**: Vite for frontend, esbuild for Node.js server.
*   **Type Checking**: `npm run check`.
*   **Database Migrations**: `npm run db:push`.

## External Dependencies

*   **Database**: Neon PostgreSQL
*   **Authentication**: Replit Auth (OIDC provider)
*   **UI Components**: Radix UI (headless), Lucide React (icons), Date-fns
*   **Development Tools (Replit Plugins)**: `@replit/vite-plugin-runtime-error-modal`, `@replit/vite-plugin-cartographer`, `@replit/vite-plugin-dev-banner`
*   **Form Handling**: React Hook Form, Hookform Resolvers (Zod integration)
*   **Third-party Services**: Google Maps API (@googlemaps/markerclusterer for clustering), Google Fonts, Unsplash (for placeholder images).
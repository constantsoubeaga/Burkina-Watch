import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import SOSButton from "@/components/SOSButton";
import GoogleMap from "@/components/GoogleMap";
import FilterChips from "@/components/FilterChips";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2, BarChart3 } from "lucide-react";
import type { Categorie, Signalement } from "@shared/schema";

export default function Carte() {
  const [filter, setFilter] = useState<Categorie | "tous">("tous");
  const [showStats, setShowStats] = useState(false);

  const { data: signalements, isLoading } = useQuery<Signalement[]>({
    queryKey: ["/api/signalements"],
  });

  const markers = signalements?.map(s => ({
    id: s.id,
    lat: parseFloat(s.latitude),
    lng: parseFloat(s.longitude),
    categorie: s.categorie as Categorie,
    titre: s.titre,
    isSOS: s.isSOS || false,
    niveauUrgence: s.niveauUrgence,
  })) || [];

  const filteredMarkers = filter === "tous" 
    ? markers 
    : markers.filter(m => m.categorie === filter);

  const sosCount = filteredMarkers.filter(m => m.isSOS).length;
  const urgencyStats = {
    faible: filteredMarkers.filter(m => m.niveauUrgence === 'faible').length,
    moyen: filteredMarkers.filter(m => m.niveauUrgence === 'moyen').length,
    critique: filteredMarkers.filter(m => m.niveauUrgence === 'critique').length,
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <Header />
        <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      <div className="relative h-[calc(100vh-4rem-4rem)] md:h-[calc(100vh-4rem)]">
        <div className="absolute top-2 left-2 right-2 md:top-4 md:left-4 md:right-4 z-30 max-w-md">
          <Card className="p-3 md:p-4 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/90 shadow-lg border-2">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h2 className="text-base md:text-lg font-semibold">Carte Interactive</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowStats(!showStats)}
                title="Afficher les statistiques"
                data-testid="button-toggle-stats"
              >
                <BarChart3 className="w-4 h-4" />
              </Button>
            </div>
            
            <FilterChips onFilterChange={setFilter} />
            
            {showStats && (
              <div className="mt-3 p-3 bg-primary/10 rounded-md border border-primary/30 animate-in slide-in-from-top-2 duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="w-4 h-4 text-primary" />
                  <p className="text-xs font-medium text-primary">Statistiques en temps réel</p>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-2 p-2 bg-background/60 rounded">
                    <span className="font-semibold">{filteredMarkers.length}</span>
                    <span className="text-muted-foreground">Total</span>
                  </div>
                  {sosCount > 0 && (
                    <div className="flex items-center gap-2 p-2 bg-red-500/10 rounded border border-red-500/30">
                      <span className="font-semibold text-red-600">{sosCount}</span>
                      <span className="text-red-600">SOS</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 p-2 bg-background/60 rounded">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="font-semibold">{urgencyStats.faible}</span>
                    <span className="text-muted-foreground">Faible</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-background/60 rounded">
                    <div className="w-2 h-2 rounded-full bg-orange-500" />
                    <span className="font-semibold">{urgencyStats.moyen}</span>
                    <span className="text-muted-foreground">Moyen</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-background/60 rounded col-span-2">
                    <div className="w-2 h-2 rounded-full bg-red-500" />
                    <span className="font-semibold">{urgencyStats.critique}</span>
                    <span className="text-muted-foreground">Critique</span>
                  </div>
                </div>
              </div>
            )}

            <p className="text-xs text-muted-foreground mt-3 flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-primary animate-pulse" />
              {filteredMarkers.length} signalement{filteredMarkers.length > 1 ? "s" : ""} affiché{filteredMarkers.length > 1 ? "s" : ""}
            </p>
          </Card>
        </div>

        <GoogleMap markers={filteredMarkers} className="h-full" />
      </div>

      <SOSButton onClick={() => window.location.href = "/sos/publier"} />
      <BottomNav />
    </div>
  );
}

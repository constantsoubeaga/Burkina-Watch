import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Upload, MapPin, Camera, Loader2, X, AlertTriangle, Phone } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSignalementSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useState, useRef } from "react";
import { z } from "zod";

const frontendSignalementSchema = insertSignalementSchema.omit({ userId: true });
type FrontendSignalement = z.infer<typeof frontendSignalementSchema>;

export default function SOSPublier() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<FrontendSignalement>({
    resolver: zodResolver(frontendSignalementSchema),
    defaultValues: {
      titre: "",
      description: "",
      categorie: "urgence",
      latitude: "12.3714",
      longitude: "-1.5197",
      localisation: "",
      photo: "",
      video: "",
      isAnonymous: false,
      isSOS: true,
      niveauUrgence: "critique",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FrontendSignalement) => {
      const res = await apiRequest("POST", "/api/signalements", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/signalements"] });
      toast({
        title: "🚨 SOS Envoyé",
        description: "Votre alerte d'urgence a été diffusée. Les autorités ont été notifiées.",
      });
      form.reset();
      setLocation("/sos");
    },
    onError: (error: any) => {
      console.error("Erreur complète:", error);
      const errorMessage = error?.message || error?.error || "Une erreur est survenue lors de l'envoi du SOS.";
      toast({
        title: "Erreur",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          form.setValue("latitude", position.coords.latitude.toString());
          form.setValue("longitude", position.coords.longitude.toString());
          form.setValue("localisation", `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`);
          toast({
            title: "Position obtenue",
            description: "Votre localisation a été détectée automatiquement.",
          });
        },
        () => {
          toast({
            title: "Erreur",
            description: "Impossible d'obtenir votre position.",
            variant: "destructive",
          });
        }
      );
    }
  };

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          const MAX_WIDTH = 1200;
          const MAX_HEIGHT = 1200;
          let width = img.width;
          let height = img.height;
          
          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          ctx?.drawImage(img, 0, 0, width, height);
          
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.8);
          resolve(compressedBase64);
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) {
        toast({
          title: "Fichier trop volumineux",
          description: "La taille maximale est de 20 MB",
          variant: "destructive",
        });
        return;
      }

      try {
        const compressedBase64 = await compressImage(file);
        setPhotoPreview(compressedBase64);
        form.setValue("photo", compressedBase64);
      } catch (error) {
        toast({
          title: "Erreur",
          description: "Impossible de traiter l'image",
          variant: "destructive",
        });
      }
    }
  };

  const handleRemovePhoto = () => {
    setPhotoPreview(null);
    form.setValue("photo", "");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleCameraClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const onSubmit = (data: FrontendSignalement) => {
    createMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-destructive/5 pb-24">
      <Header />

      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card className="mb-6 bg-destructive border-destructive">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1 text-white">
                <h2 className="text-xl font-bold mb-2">🚨 Alerte SOS d'Urgence</h2>
                <p className="text-white/90 text-sm">
                  Ce formulaire est destiné aux <strong>situations d'urgence réelle</strong> nécessitant une intervention immédiate des autorités.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <Phone className="w-8 h-8 mx-auto mb-2 text-primary" />
              <p className="font-semibold">Police</p>
              <p className="text-2xl font-bold text-primary">17</p>
            </CardContent>
          </Card>
          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <Phone className="w-8 h-8 mx-auto mb-2 text-destructive" />
              <p className="font-semibold">Pompiers</p>
              <p className="text-2xl font-bold text-destructive">18</p>
            </CardContent>
          </Card>
          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <Phone className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="font-semibold">SAMU</p>
              <p className="text-2xl font-bold text-green-600">112</p>
            </CardContent>
          </Card>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <Card>
              <CardHeader className="bg-destructive/10">
                <CardTitle className="text-destructive">Détails de l'urgence</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <FormField
                  control={form.control}
                  name="titre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Titre de l'urgence *</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Ex: Accident grave, Incendie, Personne en danger..."
                          {...field}
                          data-testid="input-sos-title"
                          className="border-destructive/50"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description détaillée *</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Décrivez la situation d'urgence en détail : que s'est-il passé ? Combien de personnes ? Blessés ?"
                          className="min-h-32 border-destructive/50"
                          {...field}
                          data-testid="input-sos-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="niveauUrgence"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Niveau d'urgence *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "critique"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-urgence-level" className="border-destructive/50">
                            <SelectValue placeholder="Sélectionnez le niveau" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="critique">🔴 Critique - Danger immédiat</SelectItem>
                          <SelectItem value="moyen">🟡 Moyen - Intervention rapide</SelectItem>
                          <SelectItem value="faible">🟢 Faible - Non urgent</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="localisation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Localisation exacte *</FormLabel>
                      <div className="flex flex-wrap gap-2">
                        <FormControl>
                          <Input
                            placeholder="Adresse précise ou points de repère"
                            {...field}
                            value={field.value || ""}
                            data-testid="input-sos-location"
                            className="border-destructive/50 flex-1 min-w-[200px]"
                          />
                        </FormControl>
                        <Button
                          type="button"
                          variant="destructive"
                          onClick={handleGetLocation}
                          data-testid="button-get-location-sos"
                        >
                          <MapPin className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Cliquez sur l'icône pour utiliser votre position GPS actuelle
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="space-y-2">
                  <Label>Photo de la situation (recommandé)</Label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                    className="hidden"
                    data-testid="input-sos-file"
                  />
                  
                  {photoPreview ? (
                    <div className="relative border-2 border-destructive rounded-lg overflow-hidden">
                      <img
                        src={photoPreview}
                        alt="Prévisualisation"
                        className="w-full h-64 object-cover"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={handleRemovePhoto}
                        data-testid="button-remove-photo-sos"
                      >
                        <X className="w-4 h-4 mr-1" />
                        Supprimer
                      </Button>
                    </div>
                  ) : (
                    <div 
                      className="border-2 border-dashed border-destructive rounded-lg p-8 text-center hover-elevate cursor-pointer bg-destructive/5"
                      onClick={handleCameraClick}
                    >
                      <Upload className="w-12 h-12 mx-auto mb-4 text-destructive" />
                      <p className="text-sm text-muted-foreground mb-1">
                        Cliquez pour télécharger une photo
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Une photo aide les secours à évaluer la situation
                      </p>
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="mt-4"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCameraClick();
                        }}
                        data-testid="button-upload-photo-sos"
                      >
                        <Camera className="w-4 h-4 mr-2" />
                        Prendre une photo
                      </Button>
                    </div>
                  )}
                </div>

                <FormField
                  control={form.control}
                  name="isAnonymous"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-muted/50 rounded-lg">
                        <div className="space-y-0.5">
                          <FormLabel>Rester anonyme</FormLabel>
                          <p className="text-xs text-muted-foreground">
                            Votre identité ne sera pas révélée publiquement
                          </p>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value || false}
                            onCheckedChange={field.onChange}
                            data-testid="switch-anonymous-sos"
                          />
                        </FormControl>
                      </div>
                    </FormItem>
                  )}
                />

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button 
                    type="submit" 
                    className="flex-1 bg-destructive hover:bg-destructive/90" 
                    disabled={createMutation.isPending}
                    data-testid="button-submit-sos"
                  >
                    {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Envoyer l'alerte SOS
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setLocation("/sos")}
                    data-testid="button-cancel-sos"
                  >
                    Annuler
                  </Button>
                </div>
              </CardContent>
            </Card>
          </form>
        </Form>
      </div>

      <BottomNav />
    </div>
  );
}

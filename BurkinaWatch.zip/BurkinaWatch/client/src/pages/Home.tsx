import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import SOSButton from "@/components/SOSButton";
import SignalementCard from "@/components/SignalementCard";
import StatCard from "@/components/StatCard";
import MessageDuJour from "@/components/MessageDuJour";
import { AlertCircle, Shield, Users, TrendingUp, ArrowRight, Loader2, Heart } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { Signalement } from "@shared/schema";
import heroImage from "@assets/generated_images/Citizens_collaborating_with_smartphones_in_Burkina_68dc35a5.png";

interface Stats {
  totalSignalements: number;
  sosCount: number;
  totalUsers: number;
}

export default function Home() {
  const { data: signalements = [], isLoading } = useQuery<Signalement[]>({
    queryKey: ["/api/signalements"],
    queryFn: async () => {
      const response = await fetch("/api/signalements?limit=6");
      if (!response.ok) throw new Error("Erreur lors du chargement");
      return response.json();
    },
  });

  const { data: stats } = useQuery<Stats>({
    queryKey: ["/api/stats"],
    queryFn: async () => {
      const response = await fetch("/api/stats");
      if (!response.ok) throw new Error("Erreur lors du chargement des statistiques");
      return response.json();
    },
  });

  const recentReports = signalements.slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Citoyens burkinabè engagés"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-background" />
        </div>
        
        <div className="relative z-10 text-center px-4 text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Burkina Watch
          </h1>
          <p className="text-xl md:text-2xl mb-2 font-semibold">
            <span className="text-red-500 dark:text-red-400">Voir.</span>{" "}
            <span className="text-yellow-300 dark:text-yellow-400">Agir.</span>{" "}
            <span className="text-green-400 dark:text-green-400">Protéger.</span>
          </p>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            Application nationale de veille citoyenne et d'alerte sociale
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/publier">
              <Button size="lg" className="backdrop-blur-sm bg-red-600 hover:bg-red-700 text-white border-red-700" data-testid="button-new-report">
                <AlertCircle className="w-5 h-5 mr-2" />
                Nouveau signalement
              </Button>
            </Link>
            <Link href="/carte">
              <Button size="lg" variant="outline" className="backdrop-blur-sm bg-background/10 border-white text-white hover:bg-background/20" data-testid="button-view-map">
                Voir la carte
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <StatCard
            title="Signalements actifs"
            value={stats?.totalSignalements.toString() || "0"}
            icon={AlertCircle}
            description="Dans la base de données"
          />
          <StatCard
            title="Alertes SOS"
            value={stats?.sosCount.toString() || "0"}
            icon={TrendingUp}
            description="Nécessitent attention urgente"
          />
          <StatCard
            title="Citoyens engagés"
            value={stats?.totalUsers.toLocaleString('fr-FR') || "0"}
            icon={Users}
            description="Utilisateurs actifs"
          />
        </div>

        <div className="mb-12">
          <MessageDuJour />
        </div>

        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold">Signalements récents</h2>
            <p className="text-muted-foreground">Dernières alertes de la communauté</p>
          </div>
          <Link href="/feed">
            <Button variant="ghost" data-testid="button-view-all">
              Voir tout
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentReports.map((report) => (
              <SignalementCard 
                key={report.id} 
                {...report}
                createdAt={new Date(report.createdAt!)}
              />
            ))}
          </div>
        )}

        <Card className="mt-12 bg-primary/5 border-primary/20">
          <CardContent className="p-8 text-center">
            <Shield className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h3 className="text-2xl font-bold mb-2">Ensemble, protégeons notre pays</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Signalez les problèmes dans votre quartier, aidez ceux dans le besoin, et contribuez à bâtir un Burkina Faso plus sûr et plus solidaire.
            </p>
            <Link href="/contribuer">
              <Button size="lg" data-testid="button-contribute" className="gap-2">
                <Heart className="w-5 h-5" />
                Contribuer maintenant
              </Button>
            </Link>
          </CardContent>
        </Card>
      </section>

      <SOSButton onClick={() => window.location.href = "/sos"} />
      <BottomNav />
    </div>
  );
}

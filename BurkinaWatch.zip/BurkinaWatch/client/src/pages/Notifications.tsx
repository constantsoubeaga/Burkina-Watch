import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bell, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Notifications() {
  // Mock notifications - in real app, fetch from API
  const notifications = [
    {
      id: "1",
      type: "urgence",
      title: "Nouveau signalement SOS",
      description: "Un signalement urgent a été créé dans votre zone",
      time: "Il y a 5 minutes",
      read: false,
    },
    {
      id: "2",
      type: "resolu",
      title: "Signalement résolu",
      description: "Le problème d'infrastructure que vous avez signalé a été résolu",
      time: "Il y a 1 heure",
      read: false,
    },
    {
      id: "3",
      type: "info",
      title: "Mise à jour du système",
      description: "Burkina Watch a été mis à jour avec de nouvelles fonctionnalités",
      time: "Il y a 3 heures",
      read: true,
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case "urgence":
        return <AlertTriangle className="w-5 h-5 text-destructive" />;
      case "resolu":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      default:
        return <Info className="w-5 h-5 text-blue-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Notifications</h1>
          <p className="text-muted-foreground">
            Restez informé des dernières mises à jour
          </p>
        </div>

        <div className="space-y-4">
          {notifications.map((notification) => (
            <Card
              key={notification.id}
              className={!notification.read ? "border-l-4 border-l-primary" : ""}
              data-testid={`notification-${notification.id}`}
            >
              <CardHeader>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    {getIcon(notification.type)}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <CardTitle className="text-base">
                          {notification.title}
                        </CardTitle>
                        {!notification.read && (
                          <Badge variant="default" className="h-2 w-2 p-0 rounded-full" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {notification.description}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {notification.time}
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}

          {notifications.length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Bell className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground text-center">
                  Aucune notification pour le moment
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}

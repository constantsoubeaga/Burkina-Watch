import { Button } from "@/components/ui/button";
import type { Categorie } from "@shared/schema";
import { useState } from "react";

const categories: { value: Categorie | "tous"; label: string }[] = [
  { value: "tous", label: "Tous" },
  { value: "urgence", label: "Urgence" },
  { value: "securite", label: "Sécurité" },
  { value: "sante", label: "Santé" },
  { value: "environnement", label: "Environnement" },
  { value: "corruption", label: "Corruption" },
  { value: "infrastructure", label: "Infrastructure" },
  { value: "personne_recherchee", label: "Personne recherchée" },
];

interface FilterChipsProps {
  onFilterChange?: (filter: Categorie | "tous") => void;
}

export default function FilterChips({ onFilterChange }: FilterChipsProps) {
  const [selected, setSelected] = useState<Categorie | "tous">("tous");

  const handleSelect = (value: Categorie | "tous") => {
    setSelected(value);
    onFilterChange?.(value);
    console.log("Filter changed to:", value);
  };

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {categories.map((category) => (
        <Button
          key={category.value}
          variant={selected === category.value ? "default" : "outline"}
          size="sm"
          onClick={() => handleSelect(category.value)}
          className="whitespace-nowrap toggle-elevate"
          data-testid={`filter-${category.value}`}
        >
          {category.label}
        </Button>
      ))}
    </div>
  );
}

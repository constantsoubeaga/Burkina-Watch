import { Button } from "@/components/ui/button";
import { Moon, Sun, Menu, Bell, LogIn, User } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import HamburgerMenu from "./HamburgerMenu";
import logo from "@assets/burkina_watch_logo.png";
import { Link } from "wouter";
import { useState } from "react";

interface HeaderProps {
  onMenuClick?: () => void;
  showNotifications?: boolean;
  showLogout?: boolean;
}

export default function Header({ onMenuClick, showNotifications = true, showLogout = true }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const { isAuthenticated, user } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const getInitials = () => {
    if (!user) return "U";
    const first = user.firstName?.[0] || "";
    const last = user.lastName?.[0] || "";
    return (first + last).toUpperCase() || "U";
  };

  return (
    <>
      <HamburgerMenu open={menuOpen} onOpenChange={setMenuOpen} />
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMenuOpen(true)}
              data-testid="button-menu"
            >
              <Menu className="w-5 h-5" />
            </Button>
          <Link href="/" className="flex items-center gap-3" data-testid="link-home">
            <img src={logo} alt="Burkina Watch" className="w-10 h-10" />
            <div className="hidden md:block">
              <h1 className="text-lg font-bold text-red-600 dark:text-red-500">Burkina Watch</h1>
              <p className="text-xs">
                <span className="text-red-600 dark:text-red-500">Voir.</span>{" "}
                <span className="text-yellow-700 dark:text-yellow-400">Agir.</span>{" "}
                <span className="text-green-700 dark:text-green-500">Protéger.</span>
              </p>
            </div>
          </Link>
        </div>

        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <>
              {showNotifications && (
                <Link href="/notifications">
                  <Button variant="ghost" size="icon" data-testid="button-notifications">
                    <Bell className="w-5 h-5" />
                  </Button>
                </Link>
              )}
              <Link href="/profil">
                <Button variant="ghost" size="icon" data-testid="button-profile-link">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user?.profileImageUrl || ""} style={{ objectFit: "cover" }} />
                    <AvatarFallback className="text-xs">{getInitials()}</AvatarFallback>
                  </Avatar>
                </Button>
              </Link>
            </>
          ) : (
            <Button 
              size="icon"
              onClick={handleLogin}
              data-testid="button-login"
              className="bg-yellow-600 hover:bg-yellow-700 text-white"
              aria-label="Se connecter"
            >
              <LogIn className="w-5 h-5" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {theme === "light" ? (
              <Moon className="w-5 h-5" />
            ) : (
              <Sun className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>
    </header>
    </>
  );
}

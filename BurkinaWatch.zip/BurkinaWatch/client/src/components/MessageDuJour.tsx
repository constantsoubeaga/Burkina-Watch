import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, Quote, Sparkles } from "lucide-react";
import { getMessageDuJour } from "@/lib/messagesDuJour";

const iconMap = {
  proverbe: Quote,
  conseil: Lightbulb,
  encouragement: Sparkles,
};

export default function MessageDuJour() {
  const message = getMessageDuJour();
  const Icon = iconMap[message.type];

  return (
    <Card 
      className="border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10 hover-elevate" 
      data-testid="card-message-du-jour"
    >
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon className="w-6 h-6 text-primary" />
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-sm uppercase tracking-wide text-primary">
                {message.type === 'proverbe' && 'Proverbe du jour'}
                {message.type === 'conseil' && 'Conseil du jour'}
                {message.type === 'encouragement' && 'Message du jour'}
              </h3>
            </div>
            <blockquote className="text-foreground text-lg font-medium leading-relaxed italic">
              "{message.texte}"
            </blockquote>
            {message.auteur && (
              <p className="text-sm text-muted-foreground mt-3">
                — {message.auteur}
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

import { Button } from "@/components/ui/button";
import { Home, Map, Plus, AlertCircle, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

export default function BottomNav() {
  const [location] = useLocation();
  const { isAuthenticated } = useAuth();

  const navItems = [
    { icon: Home, label: "Accueil", path: "/", testId: "nav-home" },
    { icon: Map, label: "Carte", path: "/carte", testId: "nav-map" },
    { icon: Plus, label: "Publier", path: "/publier", testId: "nav-publish", highlight: true },
    { icon: AlertCircle, label: "SOS", path: "/sos", testId: "nav-sos" },
    { icon: User, label: "Profil", path: "/profil", testId: "nav-profile" },
  ];

  return (
    <nav className={`fixed bottom-0 left-0 right-0 z-40 bg-background border-t ${!isAuthenticated ? 'md:hidden' : ''}`} data-testid="bottom-nav">
      <div className="flex items-center justify-around h-16 px-1 gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                size="sm"
                className={`flex flex-col items-center gap-1 h-auto py-2 ${
                  isActive && !item.highlight ? "text-primary" : item.highlight ? "text-red-600 dark:text-red-500" : "text-muted-foreground"
                }`}
                data-testid={item.testId}
              >
                <Icon className={`w-5 h-5 ${item.highlight ? "text-red-600 dark:text-red-500" : ""}`} />
                <span className="text-xs">{item.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

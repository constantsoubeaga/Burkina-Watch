import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

interface SOSButtonProps {
  onClick?: () => void;
}

export default function SOSButton({ onClick }: SOSButtonProps) {
  return (
    <Button
      size="lg"
      className="fixed bottom-20 right-4 md:bottom-8 md:right-8 w-16 h-16 rounded-full bg-category-urgence hover:bg-category-urgence text-white shadow-2xl z-50 animate-pulse"
      onClick={onClick}
      data-testid="button-sos"
    >
      <div className="flex flex-col items-center">
        <AlertCircle className="w-6 h-6" />
        <span className="text-xs font-bold">SOS</span>
      </div>
    </Button>
  );
}

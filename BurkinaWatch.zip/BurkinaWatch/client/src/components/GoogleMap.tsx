/**
 * GoogleMap Component
 * 
 * Affiche une carte Google Maps interactive avec les signalements géolocalisés.
 * 
 * Configuration requise :
 * - Clé API Google Maps stockée dans VITE_GOOGLE_MAPS_API_KEY
 * - API "Maps JavaScript API" activée dans Google Cloud Console
 * - Facturation activée sur le projet Google Cloud
 * 
 * Gestion d'erreur :
 * - Si la clé API est manquante : affiche un message d'erreur
 * - Si l'API échoue au chargement (onError callback) : affiche un fallback avec liste des signalements
 * - Si une erreur de facturation apparaît (détection DOM) : affiche un fallback avec liste des signalements
 * 
 * Le fallback affiche jusqu'à 5 signalements avec leurs coordonnées GPS et permet
 * toujours le filtrage par catégorie via les FilterChips.
 */
import { APIProvider, Map, AdvancedMarker, InfoWindow, useMap } from '@vis.gl/react-google-maps';
import { useState, useEffect, useRef } from 'react';
import { MarkerClusterer } from '@googlemaps/markerclusterer';
import type { Marker } from '@googlemaps/markerclusterer';
import type { Categorie, NiveauUrgence } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, AlertTriangle, Locate, TrendingUp } from 'lucide-react';

interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  categorie: Categorie;
  titre: string;
  isSOS?: boolean;
  niveauUrgence?: string | null;
}

interface GoogleMapProps {
  markers: MapMarker[];
  className?: string;
}

const BURKINA_FASO_CENTER = {
  lat: 12.3714,
  lng: -1.5197
};

const BURKINA_FASO_BOUNDS = {
  north: 15.086,
  south: 9.410,
  east: 2.407,
  west: -5.523
};

const categoryColors: Record<Categorie, string> = {
  urgence: '#E30613',
  securite: '#FF6B35',
  sante: '#4ECDC4',
  environnement: '#007A33',
  corruption: '#95E1D3',
  infrastructure: '#FFD100',
  personne_recherchee: '#D97706'
};

const urgencyColors: Record<string, string> = {
  faible: '#22c55e',
  moyen: '#f97316',
  critique: '#ef4444'
};

function CustomMarker({ color, isSOS, niveauUrgence }: { color: string; isSOS: boolean; niveauUrgence?: string | null }) {
  const urgencyColor = niveauUrgence ? urgencyColors[niveauUrgence] || urgencyColors.moyen : urgencyColors.moyen;
  
  return (
    <div style={{ position: 'relative' }}>
      {isSOS && (
        <>
          <div 
            className="absolute inset-0 rounded-full animate-ping"
            style={{
              width: '60px',
              height: '60px',
              backgroundColor: color,
              opacity: 0.4,
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              animationDuration: '2s'
            }}
          />
          <div 
            className="absolute inset-0 rounded-full animate-pulse"
            style={{
              width: '48px',
              height: '48px',
              backgroundColor: color,
              opacity: 0.3,
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              animationDuration: '1.5s'
            }}
          />
        </>
      )}
      <div 
        style={{
          width: isSOS ? '36px' : '30px',
          height: isSOS ? '36px' : '30px',
          backgroundColor: color,
          borderRadius: '50% 50% 50% 0',
          transform: 'rotate(-45deg)',
          border: '2px solid white',
          boxShadow: isSOS ? '0 4px 12px rgba(227, 6, 19, 0.5)' : '0 2px 4px rgba(0,0,0,0.3)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          transition: 'all 0.3s ease'
        }}
      >
        {isSOS ? (
          <AlertTriangle 
            size={16} 
            color="white" 
            style={{ transform: 'rotate(45deg)' }}
          />
        ) : (
          <MapPin 
            size={14} 
            color="white" 
            style={{ transform: 'rotate(45deg)' }}
          />
        )}
      </div>
      <div 
        style={{
          position: 'absolute',
          top: '-4px',
          right: '-4px',
          width: '12px',
          height: '12px',
          backgroundColor: urgencyColor,
          borderRadius: '50%',
          border: '2px solid white',
          boxShadow: '0 1px 3px rgba(0,0,0,0.4)',
          zIndex: 10
        }}
        title={`Niveau d'urgence: ${niveauUrgence || 'moyen'}`}
      />
    </div>
  );
}

function RecenterControl() {
  const map = useMap();

  const handleRecenter = () => {
    if (map) {
      map.panTo(BURKINA_FASO_CENTER);
      map.setZoom(6.5);
    }
  };

  return (
    <div className="absolute bottom-4 right-4 z-20">
      <Button
        onClick={handleRecenter}
        size="icon"
        variant="secondary"
        className="shadow-lg hover-elevate active-elevate-2"
        title="Recentrer sur le Burkina Faso"
        data-testid="button-recenter-map"
      >
        <Locate className="w-5 h-5" />
      </Button>
    </div>
  );
}

interface ClusteredMarkersProps {
  markers: MapMarker[];
  onMarkerClick: (marker: MapMarker) => void;
}

function ClusteredMarkers({ markers, onMarkerClick }: ClusteredMarkersProps) {
  const map = useMap();
  const [markerRefs, setMarkerRefs] = useState<{[key: string]: Marker}>({});
  const clusterer = useRef<MarkerClusterer | null>(null);

  useEffect(() => {
    if (!map) return;
    
    if (!clusterer.current) {
      clusterer.current = new MarkerClusterer({ 
        map,
        renderer: {
          render: ({ count, position }) => {
            const color = count > 10 ? '#ef4444' : count > 5 ? '#f97316' : '#22c55e';
            // @ts-expect-error - Google Maps API types
            return new window.google.maps.Marker({
              position,
              icon: {
                // @ts-expect-error - Google Maps API types
                path: window.google.maps.SymbolPath.CIRCLE,
                scale: Math.min(20 + (count * 2), 50),
                fillColor: color,
                fillOpacity: 0.85,
                strokeColor: 'white',
                strokeWeight: 3,
              },
              label: {
                text: String(count),
                color: 'white',
                fontSize: '14px',
                fontWeight: 'bold',
              },
              // @ts-expect-error - Google Maps API types
              zIndex: Number(window.google.maps.Marker.MAX_ZINDEX) + count,
            });
          },
        },
      });
    }
  }, [map]);

  useEffect(() => {
    if (!clusterer.current) return;
    
    clusterer.current.clearMarkers();
    clusterer.current.addMarkers(Object.values(markerRefs));
  }, [markerRefs]);

  const setMarkerRef = (marker: Marker | null, key: string) => {
    if (marker && markerRefs[key]) return;
    if (!marker && !markerRefs[key]) return;

    setMarkerRefs(prev => {
      if (marker) {
        return {...prev, [key]: marker};
      } else {
        const newMarkers = {...prev};
        delete newMarkers[key];
        return newMarkers;
      }
    });
  };

  const nonSOSMarkers = markers.filter(m => !m.isSOS);

  return (
    <>
      {nonSOSMarkers.map((marker) => (
        <AdvancedMarker
          key={marker.id}
          position={{ lat: marker.lat, lng: marker.lng }}
          ref={(markerRef) => setMarkerRef(markerRef, marker.id)}
          onClick={() => onMarkerClick(marker)}
        >
          <CustomMarker 
            color={categoryColors[marker.categorie]}
            isSOS={false}
            niveauUrgence={marker.niveauUrgence}
          />
        </AdvancedMarker>
      ))}
    </>
  );
}

function calculateNearbyStats(marker: MapMarker, allMarkers: MapMarker[], radiusKm: number = 10): {
  total: number;
  byUrgency: { faible: number; moyen: number; critique: number };
  byCategory: Partial<Record<Categorie, number>>;
} {
  const R = 6371;
  
  const toRad = (deg: number) => deg * (Math.PI / 180);
  
  const distance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const nearby = allMarkers.filter(m => {
    if (m.id === marker.id) return false;
    const dist = distance(marker.lat, marker.lng, m.lat, m.lng);
    return dist <= radiusKm;
  });

  const byUrgency = { faible: 0, moyen: 0, critique: 0 };
  const byCategory: Partial<Record<Categorie, number>> = {};

  nearby.forEach(m => {
    const urgency = m.niveauUrgence || 'moyen';
    if (urgency in byUrgency) {
      byUrgency[urgency as keyof typeof byUrgency]++;
    }
    byCategory[m.categorie] = (byCategory[m.categorie] || 0) + 1;
  });

  return {
    total: nearby.length,
    byUrgency,
    byCategory,
  };
}

export default function GoogleMap({ markers, className = '' }: GoogleMapProps) {
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);
  const [mapError, setMapError] = useState<boolean>(false);
  const [mapLoaded, setMapLoaded] = useState<boolean>(false);
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

  useEffect(() => {
    const checkInterval = setInterval(() => {
      const errorElement = document.querySelector('.gm-err-message, .gm-err-content, .gm-err-title');
      const errorDialog = document.querySelector('[role="dialog"]');
      
      if (errorElement || (errorDialog && errorDialog.textContent?.includes('Google Maps'))) {
        console.error('Google Maps error detected in DOM');
        setMapError(true);
        clearInterval(checkInterval);
      }
    }, 300);

    const forceErrorTimeout = setTimeout(() => {
      if (!mapLoaded && !mapError) {
        console.error('Google Maps failed to load within timeout, showing fallback');
        setMapError(true);
      }
      clearInterval(checkInterval);
    }, 5000);

    return () => {
      clearInterval(checkInterval);
      clearTimeout(forceErrorTimeout);
    };
  }, [mapLoaded, mapError]);

  const handleApiError = (error: unknown) => {
    console.error('Google Maps API loading error:', error);
    setMapError(true);
  };

  const handleApiLoad = () => {
    console.log('Google Maps API loaded successfully');
    setMapLoaded(true);
  };

  if (!apiKey) {
    return (
      <div className={`flex flex-col items-center justify-center bg-muted/10 p-8 ${className}`}>
        <AlertTriangle className="w-12 h-12 mb-4 text-destructive" />
        <p className="text-muted-foreground text-center">Clé API Google Maps non configurée</p>
      </div>
    );
  }

  if (mapError) {
    return (
      <div className={`flex flex-col items-center justify-center bg-muted/10 p-8 ${className}`}>
        <AlertTriangle className="w-12 h-12 mb-4 text-destructive" />
        <h3 className="font-semibold text-lg mb-2">Erreur de chargement de la carte</h3>
        <p className="text-muted-foreground text-center max-w-md mb-4">
          La carte Google Maps n'a pas pu être chargée. Cela peut être dû à un problème de facturation ou de quota avec la clé API.
        </p>
        <div className="bg-card p-4 rounded-md border max-w-md">
          <h4 className="font-medium mb-2 text-sm">Données disponibles :</h4>
          <p className="text-sm text-muted-foreground">
            {markers.length} signalement{markers.length > 1 ? 's' : ''} géolocalisé{markers.length > 1 ? 's' : ''}
          </p>
          {markers.length > 0 && (
            <div className="mt-3 space-y-2 max-h-60 overflow-y-auto">
              {markers.slice(0, 5).map(marker => (
                <div key={marker.id} className="text-xs p-2 bg-muted rounded">
                  <div className="font-medium">{marker.titre}</div>
                  <div className="text-muted-foreground">
                    {marker.categorie} • {marker.lat.toFixed(4)}, {marker.lng.toFixed(4)}
                  </div>
                </div>
              ))}
              {markers.length > 5 && (
                <p className="text-xs text-muted-foreground text-center">
                  +{markers.length - 5} autre{markers.length - 5 > 1 ? 's' : ''}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <APIProvider 
        apiKey={apiKey}
        onLoad={handleApiLoad}
        onError={handleApiError}
      >
        <Map
          defaultCenter={BURKINA_FASO_CENTER}
          defaultZoom={6.5}
          gestureHandling="greedy"
          disableDefaultUI={false}
          restriction={{
            latLngBounds: BURKINA_FASO_BOUNDS,
            strictBounds: true
          }}
          mapId="burkina-watch-map"
        >
          <ClusteredMarkers markers={markers} onMarkerClick={setSelectedMarker} />

          {markers.filter(m => m.isSOS).map((marker) => (
            <AdvancedMarker
              key={marker.id}
              position={{ lat: marker.lat, lng: marker.lng }}
              onClick={() => setSelectedMarker(marker)}
            >
              <CustomMarker 
                color="#E30613"
                isSOS={true}
                niveauUrgence={marker.niveauUrgence}
              />
            </AdvancedMarker>
          ))}

          {selectedMarker && (() => {
            const stats = calculateNearbyStats(selectedMarker, markers, 10);
            return (
              <InfoWindow
                position={{ lat: selectedMarker.lat, lng: selectedMarker.lng }}
                onCloseClick={() => setSelectedMarker(null)}
                data-testid={`infowindow-${selectedMarker.id}`}
              >
                <div className="p-2 min-w-[240px]">
                  <h3 className="font-semibold text-sm mb-2">{selectedMarker.titre}</h3>
                  <div className="flex gap-2 items-center flex-wrap mb-3">
                    <Badge 
                      variant="outline" 
                      className="text-xs"
                      style={{ 
                        borderColor: categoryColors[selectedMarker.categorie],
                        color: categoryColors[selectedMarker.categorie]
                      }}
                    >
                      {selectedMarker.categorie}
                    </Badge>
                    {selectedMarker.isSOS && (
                      <Badge variant="destructive" className="text-xs">
                        SOS
                      </Badge>
                    )}
                    {selectedMarker.niveauUrgence && (
                      <Badge 
                        variant="outline" 
                        className="text-xs flex items-center gap-1"
                        style={{ 
                          borderColor: urgencyColors[selectedMarker.niveauUrgence] || urgencyColors.moyen,
                          color: urgencyColors[selectedMarker.niveauUrgence] || urgencyColors.moyen
                        }}
                      >
                        <div 
                          className="w-2 h-2 rounded-full" 
                          style={{ 
                            backgroundColor: urgencyColors[selectedMarker.niveauUrgence] || urgencyColors.moyen 
                          }}
                        />
                        {selectedMarker.niveauUrgence}
                      </Badge>
                    )}
                  </div>

                  {stats.total > 0 && (
                    <div className="mb-3 p-2 bg-gray-50 rounded border border-gray-200">
                      <div className="flex items-center gap-1 mb-2">
                        <TrendingUp className="w-3 h-3 text-primary" />
                        <p className="text-xs font-medium text-gray-700">Dans un rayon de 10 km:</p>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-600">Total:</span>
                          <span className="font-semibold text-gray-800">{stats.total}</span>
                        </div>
                        {(stats.byUrgency.critique > 0 || stats.byUrgency.moyen > 0 || stats.byUrgency.faible > 0) && (
                          <div className="flex gap-2 text-xs mt-2">
                            {stats.byUrgency.faible > 0 && (
                              <span className="flex items-center gap-1">
                                <div className="w-2 h-2 rounded-full bg-green-500" />
                                {stats.byUrgency.faible}
                              </span>
                            )}
                            {stats.byUrgency.moyen > 0 && (
                              <span className="flex items-center gap-1">
                                <div className="w-2 h-2 rounded-full bg-orange-500" />
                                {stats.byUrgency.moyen}
                              </span>
                            )}
                            {stats.byUrgency.critique > 0 && (
                              <span className="flex items-center gap-1">
                                <div className="w-2 h-2 rounded-full bg-red-500" />
                                {stats.byUrgency.critique}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${selectedMarker.lat},${selectedMarker.lng}`;
                      window.open(mapsUrl, '_blank', 'noopener,noreferrer');
                    }}
                    className="text-xs text-muted-foreground flex items-center gap-1 hover:text-primary transition-colors w-full"
                    data-testid={`button-open-maps-${selectedMarker.id}`}
                  >
                    <MapPin className="w-3 h-3" />
                    {selectedMarker.lat.toFixed(4)}, {selectedMarker.lng.toFixed(4)}
                    <span className="ml-auto text-primary">Ouvrir →</span>
                  </button>
                </div>
              </InfoWindow>
            );
          })()}

          <RecenterControl />
        </Map>
      </APIProvider>
    </div>
  );
}

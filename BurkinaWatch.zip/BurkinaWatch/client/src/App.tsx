import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Feed from "@/pages/Feed";
import Carte from "@/pages/Carte";
import Publier from "@/pages/Publier";
import SOS from "@/pages/SOS";
import SOSPublier from "@/pages/SOSPublier";
import Profil from "@/pages/Profil";
import Admin from "@/pages/Admin";
import Notifications from "@/pages/Notifications";
import Contribuer from "@/pages/Contribuer";
import APropos from "@/pages/APropos";
import Conditions from "@/pages/Conditions";
import NotFound from "@/pages/not-found";
import { Loader2 } from "lucide-react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/feed" component={Feed} />
      <Route path="/carte" component={Carte} />
      <Route path="/publier" component={Publier} />
      <Route path="/sos" component={SOS} />
      <Route path="/sos/publier" component={SOSPublier} />
      <Route path="/profil" component={Profil} />
      <Route path="/admin" component={Admin} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/contribuer" component={Contribuer} />
      <Route path="/a-propos" component={APropos} />
      <Route path="/conditions" component={Conditions} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
